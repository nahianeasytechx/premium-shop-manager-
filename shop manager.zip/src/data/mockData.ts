export interface Shop {
  id: number;
  shopNumber: string;
  floor: number;
  category: string;
  sqft: string;
  status: 'available' | 'booked';
  price: number;
}

export interface Booking {
  id: number;
  shopId: number;
  name: string;
  profession: string;
  mobile: string;
  address: string;
  bookingMoney: number;
  date: string;
}

export const shops: Shop[] = [
  // Ground Floor (SH-001 to SH-015)
  { id: 1, shopNumber: 'SH-001', floor: 0, category: 'Retail', sqft: '10\'4" x 13\'0"', status: 'available', price: 45000 },
  { id: 2, shopNumber: 'SH-002', floor: 0, category: 'Retail', sqft: '10\'7" x 13\'0"', status: 'booked', price: 47000 },
  { id: 3, shopNumber: 'SH-003', floor: 0, category: 'Retail', sqft: '10\'0" x 13\'0"', status: 'available', price: 43000 },
  { id: 4, shopNumber: 'SH-004', floor: 0, category: 'Retail', sqft: '11\'0" x 13\'0"', status: 'available', price: 49000 },
  { id: 5, shopNumber: 'SH-005', floor: 0, category: 'Retail', sqft: '10\'8" x 13\'0"', status: 'available', price: 46000 },
  { id: 6, shopNumber: 'SH-006', floor: 0, category: 'Retail', sqft: '10\'9" x 13\'0"', status: 'available', price: 48000 },
  { id: 7, shopNumber: 'SH-007', floor: 0, category: 'Retail', sqft: '10\'2" x 13\'0"', status: 'available', price: 44000 },
  { id: 8, shopNumber: 'SH-008', floor: 0, category: 'Retail', sqft: '10\'1" x 13\'0"', status: 'booked', price: 43000 },
  { id: 9, shopNumber: 'SH-009', floor: 0, category: 'Retail', sqft: '10\'10" x 13\'0"', status: 'available', price: 50000 },
  { id: 10, shopNumber: 'SH-010', floor: 0, category: 'Retail', sqft: '9\'10" x 13\'0"', status: 'available', price: 42000 },
  { id: 11, shopNumber: 'SH-011', floor: 0, category: 'Retail', sqft: '10\'0" x 13\'0"', status: 'booked', price: 43000 },
  { id: 12, shopNumber: 'SH-012', floor: 0, category: 'Retail', sqft: '10\'0" x 13\'0"', status: 'available', price: 43000 },
  { id: 13, shopNumber: 'SH-013', floor: 0, category: 'Retail', sqft: '10\'0" x 13\'0"', status: 'booked', price: 43000 },
  { id: 14, shopNumber: 'SH-014', floor: 0, category: 'Retail', sqft: '9\'10" x 13\'0"', status: 'available', price: 42000 },
  { id: 15, shopNumber: 'SH-015', floor: 0, category: 'Retail', sqft: '19\'8" x 11\'8"', status: 'booked', price: 75000 },

  // First Floor (SH-101 to SH-117) 
  { id: 16, shopNumber: 'SH-101', floor: 1, category: 'Retail', sqft: '11\'2" x 14\'2"', status: 'booked', price: 55000 },
  { id: 17, shopNumber: 'SH-102', floor: 1, category: 'Retail', sqft: '10\'0" x 14\'2"', status: 'available', price: 50000 },
  { id: 18, shopNumber: 'SH-103', floor: 1, category: 'Retail', sqft: '10\'0" x 14\'2"', status: 'available', price: 50000 },
  { id: 19, shopNumber: 'SH-104', floor: 1, category: 'Retail', sqft: '10\'4" x 14\'2"', status: 'available', price: 52000 },
  { id: 20, shopNumber: 'SH-105', floor: 1, category: 'Retail', sqft: '10\'7" x 14\'2"', status: 'available', price: 53000 },
  { id: 21, shopNumber: 'SH-106', floor: 1, category: 'Retail', sqft: '10\'0" x 14\'2"', status: 'booked', price: 50000 },
  { id: 22, shopNumber: 'SH-107', floor: 1, category: 'Retail', sqft: '11\'0" x 14\'2"', status: 'available', price: 55000 },
  { id: 23, shopNumber: 'SH-108', floor: 1, category: 'Retail', sqft: '10\'8" x 14\'2"', status: 'available', price: 54000 },
  { id: 24, shopNumber: 'SH-109', floor: 1, category: 'Retail', sqft: '10\'9" x 14\'2"', status: 'available', price: 54500 },
  { id: 25, shopNumber: 'SH-110', floor: 1, category: 'Retail', sqft: '10\'2" x 14\'2"', status: 'available', price: 51000 },
  { id: 26, shopNumber: 'SH-111', floor: 1, category: 'Retail', sqft: '10\'1" x 14\'2"', status: 'available', price: 50500 },
  { id: 27, shopNumber: 'SH-112', floor: 1, category: 'Retail', sqft: '10\'10" x 14\'2"', status: 'available', price: 54800 },
  { id: 28, shopNumber: 'SH-113', floor: 1, category: 'Retail', sqft: '9\'10" x 14\'2"', status: 'available', price: 49500 },
  { id: 29, shopNumber: 'SH-114', floor: 1, category: 'Retail', sqft: '10\'0" x 14\'2"', status: 'available', price: 50000 },
  { id: 30, shopNumber: 'SH-115', floor: 1, category: 'Retail', sqft: '10\'0" x 14\'2"', status: 'booked', price: 50000 },
  { id: 31, shopNumber: 'SH-116', floor: 1, category: 'Retail', sqft: '10\'0" x 14\'2"', status: 'available', price: 50000 },
  { id: 32, shopNumber: 'SH-117', floor: 1, category: 'Retail', sqft: '9\'8" x 14\'2"', status: 'available', price: 49000 },

  // Second Floor (SH-201 to SH-214)
  { id: 33, shopNumber: 'SH-201', floor: 2, category: 'Retail', sqft: '10\'0" x 14\'2"', status: 'booked', price: 48000 },
  { id: 34, shopNumber: 'SH-202', floor: 2, category: 'Retail', sqft: '10\'0" x 14\'2"', status: 'available', price: 48000 },
  { id: 35, shopNumber: 'SH-203', floor: 2, category: 'Retail', sqft: '10\'0" x 14\'2"', status: 'available', price: 48000 },
  { id: 36, shopNumber: 'SH-204', floor: 2, category: 'Retail', sqft: '10\'4" x 14\'2"', status: 'available', price: 50000 },
  { id: 37, shopNumber: 'SH-205', floor: 2, category: 'Retail', sqft: '10\'7" x 14\'2"', status: 'booked', price: 51000 },
  { id: 38, shopNumber: 'SH-206', floor: 2, category: 'Retail', sqft: '10\'8" x 14\'2"', status: 'available', price: 51500 },
  { id: 39, shopNumber: 'SH-207', floor: 2, category: 'Retail', sqft: '10\'9" x 14\'2"', status: 'available', price: 52000 },
  { id: 40, shopNumber: 'SH-208', floor: 2, category: 'Retail', sqft: '10\'10" x 14\'2"', status: 'available', price: 52500 },
  { id: 41, shopNumber: 'SH-209', floor: 2, category: 'Retail', sqft: '11\'0" x 14\'2"', status: 'available', price: 53000 },
  { id: 42, shopNumber: 'SH-210', floor: 2, category: 'Retail', sqft: '9\'10" x 14\'2"', status: 'available', price: 47000 },
  { id: 43, shopNumber: 'SH-211', floor: 2, category: 'Retail', sqft: '9\'8" x 14\'2"', status: 'available', price: 46500 },
  { id: 44, shopNumber: 'SH-212', floor: 2, category: 'Retail', sqft: '9\'2" x 14\'2"', status: 'available', price: 45000 },
  { id: 45, shopNumber: 'SH-213', floor: 2, category: 'Retail', sqft: '9\'6" x 14\'2"', status: 'booked', price: 46000 },
  { id: 46, shopNumber: 'SH-214', floor: 2, category: 'Retail', sqft: '8\'10" x 14\'2"', status: 'available', price: 44000 },

  // Additional shops with larger sizes (continuing numbering)
  { id: 47, shopNumber: 'SH-215', floor: 2, category: 'Food', sqft: '22\'0" x 12\'4"', status: 'booked', price: 85000 },
  { id: 48, shopNumber: 'SH-216', floor: 2, category: 'Food', sqft: '22\'0" x 12\'0"', status: 'available', price: 84000 },
  { id: 49, shopNumber: 'SH-217', floor: 2, category: 'Service', sqft: '19\'6" x 12\'0"', status: 'available', price: 78000 },
  { id: 50, shopNumber: 'SH-218', floor: 2, category: 'Food', sqft: '14\'0" x 12\'3"', status: 'available', price: 68000 },
  { id: 51, shopNumber: 'SH-219', floor: 2, category: 'Service', sqft: '14\'3" x 24\'5"', status: 'available', price: 110000 },
  { id: 52, shopNumber: 'SH-016', floor: 0, category: 'Food', sqft: '14\'1" x 17\'3"', status: 'available', price: 95000 },
  { id: 53, shopNumber: 'SH-017', floor: 0, category: 'Service', sqft: '13\'10" x 17\'3"', status: 'booked', price: 92000 }
];

export const bookings: Booking[] = [
  {
    id: 1,
    shopId: 2,
    name: 'John Doe',
    profession: 'Restaurant Owner',
    mobile: '+1 234 567 8900',
    address: '123 Main St, New York',
    bookingMoney: 10000,
    date: '2025-10-15',
  },
  {
    id: 2,
    shopId: 5,
    name: 'Jane Smith',
    profession: 'Boutique Owner',
    mobile: '+1 234 567 8901',
    address: '456 Oak Ave, Los Angeles',
    bookingMoney: 12000,
    date: '2025-10-18',
  },
  {
    id: 3,
    shopId: 7,
    name: 'Mike Johnson',
    profession: 'Electronics Dealer',
    mobile: '+1 234 567 8902',
    address: '789 Pine Rd, Chicago',
    bookingMoney: 11000,
    date: '2025-10-20',
  },
  {
    id: 4,
    shopId: 10,
    name: 'Sarah Williams',
    profession: 'Cafe Owner',
    mobile: '+1 234 567 8903',
    address: '321 Elm St, Houston',
    bookingMoney: 15000,
    date: '2025-10-22',
  },
  {
    id: 5,
    shopId: 13,
    name: 'David Brown',
    profession: 'Clothing Store',
    mobile: '+1 234 567 8904',
    address: '654 Maple Dr, Phoenix',
    bookingMoney: 13000,
    date: '2025-10-25',
  },
];

export const categories = ['Retail', 'Food', 'Service'];
export const floors = [0, 1, 2];
