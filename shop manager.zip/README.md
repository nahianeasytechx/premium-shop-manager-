
  # Booking Management System Dashboard

  This is a code bundle for Booking Management System Dashboard. The original project is available at https://www.figma.com/design/C0vKBATGymu6423YvyIFLZ/Booking-Management-System-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  